#include <iostream>
#include <ros/ros.h>
#include <geometry_msgs/Twist.h>
#include <opencv2/opencv.hpp>
#include <torch/script.h>
#include <torch/torch.h>

using namespace std;
using namespace cv;

// 코부기 제어 관련 변수들
const double w = 640;
const double desired_distance = 0.6;
const double distance_tolerance = 0.05;
bool KILL = false;

// 검출된 객체 유지 시간
const double object_tracking_time = 4;

// 사람 검출을 위한 클래스 이름들
const vector<string> classes = {"person"};

// 검출된 객체 시작 시간
double person_start_time = 0;

// 라이다 거리
double lidar_distance = 0;

// 코부기 Twist 메시지
geometry_msgs::Twist kobuki_twist;

// 코부기 제어를 위한 publisher
ros::Publisher kobuki_velocity_pub;

// 키보드 입력 이벤트 처리
void on_press(const ros::TimerEvent& event) {
    char c = (char)cv::waitKey(1);
    if (c == 'q' || c == 'Q' || c == 27) {
        KILL = true;
    }
}

int main(int argc, char **argv) {
    // ros 노드 초기화
    ros::init(argc, argv, "webcam_tracker");
    ros::NodeHandle nh;

    // 코부기 제어 publisher 초기화
    kobuki_velocity_pub = nh.advertise<geometry_msgs::Twist>("/mobile_base/commands/velocity", 10);

    // YOLOv5 모델 로드
    torch::jit::script::Module model = torch::jit::load("/path/to/yolov5s.pt");
    model.eval();

    // 비디오 캡처기 초기화
    cv::VideoCapture cap;
    if (!cap.open(0)) {
        std::cerr << "Cannot open camera" << std::endl;
        return -1;
    }

    // 비디오 출력 설정
    cv::VideoWriter out("output.avi", cv::VideoWriter::fourcc('M','J','P','G'), 10, cv::Size(640, 480));

    while (ros::ok()) {
        // 다음 프레임 가져오기 후 그레이스케일로 변환하기
        cv::Mat frame, gray;
        cap >> frame;
        cv::cvtColor(frame, gray, cv::COLOR_BGR2GRAY);

        // yolov5 모델에서 검출 결과 가져오기
        auto input_tensor = torch::from_blob(gray.data, {gray.rows, gray.cols, 1}, torch::kByte);
        input_tensor = input_tensor.permute({2, 0, 1});
        input_tensor = input_tensor.unsqueeze(0);
        input_tensor = input_tensor.toType(torch::kFloat);
        input_tensor = input_tensor.div(255);
        auto results = model.forward({input_tensor}).toTuple()->elements()[0].toTensor();

        // 검출된 객체 바운딩이랑 라벨 가져오기 
        auto boxes_tensor = results.select(1, 0);
        auto labels =results.select(1,0);
        std::vector<float> boxes = results.at("output_0").get<std::vector<float>>();
        std::vector<float> labels = results.at("output_1").get<std::vector<float>>();
        
        // 사람 객체 찾기
        std::vector<std::vector<float>> person_boxes;
        for (int i = 0; i < labels.size(); i++) {
            if (classes[static_cast<int>(labels[i])] == "person") {
                std::vector<float> box(4);
                box[0] = boxes[4 * i];
                box[1] = boxes[4 * i + 1];
                box[2] = boxes[4 * i + 2];
                box[3] = boxes[4 * i + 3];
                person_boxes.push_back(box);
            }
        }
        Twist kobuki_twist;

        // 사람 객체가 검출되면 
        if (!person_boxes.empty()) {
            // 가장 큰 면적을 가진 박스 가져오기 
            std::vector<float> person_box = *std::max_element(person_boxes.begin(), person_boxes.end(), 
                [](const std::vector<float>& box1, const std::vector<float>& box2) {
                    return ((box1[2] - box1[0]) * (box1[3] - box1[1])) < ((box2[2] - box2[0]) * (box2[3] - box2[1]));
                });
            
            // 사람 박스 중심 좌표 가져오기 
            int x = static_cast<int>((person_box[0] + person_box[2]) / 2);
            int y = static_cast<int>((person_box[1] + person_box[3]) / 2);

            // 프레임에 사람 박스, 중심점 그리기 
            cv::rectangle(frame, cv::Point(static_cast<int>(person_box[0]), static_cast<int>(person_box[1])), 
                cv::Point(static_cast<int>(person_box[2]), static_cast<int>(person_box[3])), cv::Scalar(0, 255, 0), 2);
            cv::circle(frame, cv::Point(x, y), 5, cv::Scalar(0, 0, 255), -1);

            // 검출된 객체가 5초 이상 유지되는지 확인
            if (person_start_time == -1) {
                person_start_time = ros::Time::now().toSec();
            } else if (ros::Time::now().toSec() - person_start_time >= object_tracking_time) {
                // 사람 박스의 중심과 프레임 중심 간의 오차 계산하기 
                double error_x = (x - w/2) / w;

                // 오차 정보 이용 -> 코부기 제어하기 
                if ((person_box[2]-person_box[0]) < 270.0) {
                    kobuki_twist.linear.x = 0.5;
                }

                if (person_start_time != -1 && ros::Time::now().toSec() - person_start_time >= object_tracking_time) {
                    error_x = (x - w/2) / w;
                    kobuki_twist.angular.z = -error_x * 1.3; // *2
                }

                if (lidar_distance != NULL) {
                    distance_error = lidar_distance - desired_distance;
                    if (abs(distance_error) > distance_tolerance) {
                        kobuki_twist.linear.x = 0.3 * copysign(1.0, distance_error);
                    } else if (lidar_distance <= 0.3) {
                        kobuki_twist.linear.x = 0.0;
                    }
                }
            }
                kobuki_velocity_pub.publish(kobuki_twist);
            else {
                // 사람이 검출되지 않으면 person_start_time을 다시 -1으로 설정
                person_start_time = -1;
            }
            // imshow하기
            out.write(frame);
            cv::imshow("Webcam Tracking", frame);

            // 키 확인 
            char c = cv::waitKey(1);
            if (c == 'q' || c == 'Q' || c == 27) {
                std::cout << "\nFinished" << std::endl;
                out.release();
                cv::destroyAllWindows();
                ros::shutdown();
                }
            }
        }
    }
int main(int argc, char **argv) {
    // 키보드 입력 이벤트 처리 함수
    auto on_press = [&]() {
        char c = (char)cv::waitKey(1);
        if (c == 'q' || c == 'Q' || c == 27) {
            KILL = true;
        }
    };

    // ros 노드 초기화
    ros::init(argc, argv, "webcam_tracker");
    ros::NodeHandle nh;

    // 코부기 제어 publisher 초기화
    ros::Publisher kobuki_velocity_pub = nh.advertise<geometry_msgs::Twist>("/mobile_base/commands/velocity", 10);

    // 메인 함수 실행
    try {
        main_loop(on_press);
    }
    catch (ros::Exception& e) {
        ROS_ERROR("오류 발생: %s", e.what());
    }

    return 0;
}




